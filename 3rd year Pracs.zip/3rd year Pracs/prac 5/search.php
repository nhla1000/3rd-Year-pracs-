<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h2>Search Customer Credit Limit</h2><br>

<p>Welcome <strong><?php echo "{$_SESSION['username']}" ?></strong> <a href="logout.php">logout</a></p><form action="p5ex2.php" method="POST">
        <i class="fas fa-search"></i>
    <input type="search" name="search" placeholder="search">
    <input type="submit" name="submit" value="GO">
    </form>
    <?php
    // adding database credentials 
    require_once("config.php");

    // check if the value is set 
    if(isset($_REQUEST['submit'])){
        
     //request get from the form 
    $search = $_REQUEST['search'];
    // make connection to database 
    $conn = mysqli_connect($servername, $username, $password, $database) or die("Cannot Connect to the database");
    // issue a query 
    $query = "SELECT customerNumber, customerName FROM customers
    WHERE customerName LIKE '%$search%'
    ORDER BY customerName ASC";
    $results = mysqli_query($conn,$query)  or die ("Something Went wrong with the query");

    // echo out the ordered list 
      echo "<ol>";  
    while ($row = mysqli_fetch_array($results)){
        echo "<li>";
        echo "<a href=\"credit.php?id={$row['customerNumber']}\">{$row['customerName']}</a>";
        echo "</li>";
    }
        echo "</ol>";
    // close  connection 
    mysqli_close($conn);
    }
    ?>

</body>
</html>
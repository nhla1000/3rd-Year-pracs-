<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //start session
    session_start();
    //get values from form
    $user = $_REQUEST['username'];
    $psswrd = $_REQUEST['password'];
    //check if the username & password match
    if ($user == "Thabo" && $psswrd == "abc123"){
        //user exists so set session variable to aloow access to webpages
        $_SESSION['access'] = "yes";
        $_SESSION['user'] = $user;
        //direct user
        header("Location:p5ex2.php");
    } else {
        header("Location:login.html");
    }
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Search Credit Limit</h3>
    <form action="p5ex1.php" method="POST">
        <i class="fas fa-search"></i>
        <input type="search" name="search" placeholder="search">
        <input type="submit" name="submit" value="Go">
    </form>
    <?php
    //adding database credentials 
    require_once("config.php");
    
    // check if the form has been submitted
    if(isset($_REQUEST['submit'])){
        
        //request get from the form 
        $search = $_REQUEST['search'];
        //connect to the database 
        $conn = mysqli_connect($servername, $username, $password, $database) or die("Cannot Connect to the database") ;
        //issue query
        $query = "SELECT customerNumber, customerName FROM customers
        WHERE customerName LIKE '%$search%'
        ORDER BY customerName ASC";
        $results = mysqli_query($conn,$query)  or die ("Something Went wrong with the query");
        
        echo "<ol>";
        while($row = mysqli_fetch_array($results)){
            echo "<li>";
            echo "<a href=\"credit.php?id={$row['customerNumber']}\">{$row['customerName']}</a>"; 
            echo "</li>";
        }
        echo "</ol>";

        //close the connection 
        mysqli_close($conn);
    }
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script type="text/javascript">
 google.charts.load('current', {'packages':['corechart']});
 
 google.charts.setOnLoadCallback(drawChart);

 function drawChart() {
<?php 
// adding database credentials 
require_once("config.php");

// connect to database 
$conn = mysqli_connect($servername, $username, $password, $database) or die("Cannot Connect to the database");
// issue a query 
$query = "SELECT customerName, sum(amount)
FROM payments
INNER JOIN customers
ON payments.customerNumber = customers.customerNumber
GROUP BY payments.customerNumber, customers.customerNumber
ORDER BY sum(amount) DESC
LIMIT 5";
$results = mysqli_query($conn,$query)  or die ("Something Went wrong with the query");
// create a datatable 
echo "var data = google.visualization.arrayToDataTable([";
echo "['customerName',' Amount'],";
// polulate with data from database 
while ($row=mysqli_fetch_array($results)){
    echo "['{$row['customeName']}', {$row['sum(amount)']}]," ;
}
echo "]);"; 

// close the connection 
mysqli_close($conn);
?>
    var options = {
        title: 'Amount Spent by Top 5 Customers',
        hAxis: {
          title: 'Customers'
        },
        vAxis: {
          title: 'Rands'
        }
           
    };
 var chart = new google.visualization.ColumnChart(document.getElementById("columnchart"));
chart.draw(data, options);
 }
</script>
<div id="columnchart" style="width: 900px; height: 500px;"></div>
</body>
</html>
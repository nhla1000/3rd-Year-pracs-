<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $cust_ID = $_REQUEST['id'];

    // adding database credentials
    require_once("config.php");

     //connect to the database 
     $conn = mysqli_connect($servername, $username, $password, $database) or die("Cannot Connect to the database");
     //issue query
     $query = "SELECT customerName, creditLimit FROM customers WHERE customerNumber = $cust_ID";
     $results = mysqli_query($conn,$query)  or die ("Could not execute query query");

 
        while($row = mysqli_fetch_array($results)){
            $customer = $row['customerName'];
            $credits = $row['creditLimit'];
        }
        echo "<h3>$customer</h3>";
        echo "<p>Credit limit:  R" . number_format($credits,0). "</p>";

         //close the connection 
         mysqli_close($conn);
    ?>
</body>
</html>
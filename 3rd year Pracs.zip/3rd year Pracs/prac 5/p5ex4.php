<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
    if(isset($_REQUEST['submit'])){
    // add data credentials 
    require_once("config.php");
    // make connection to database 
    $conn = mysqli_connect($servername, $username, $password, $database) or die("Cannot Connect to the database");

    // issue a query instructions 
    $query = "SELECT customerName, creditLimit FROM customers ORDER BY customerName ASC";
    $results = mysqli_query($conn,$query)  or die ("Something Went wrong with the query");
    //provide file name 
    $filename = "credit.txt" ;
    // Open the file 
    $file = fopen($filename,"a") or die ("ERROR:unable open file!");

    //extract data from the data database 
    while($row=mysqli_fetch_array($results)){
        $text = $row['customerName'] . " = R" . $row['creditLimit'] . "\n" ;

        // write the text to file
        fwrite($file,$text);
} 

    // close the file
    fclose($file);
    // close the connection 
    mysqli_close($conn);

    echo "<p style=\"color:green;\">The data was successfully exported</p>";
    
}
?>
        <h3>Customer Credit Limit</h3><br>
        <form action="p5ex4.php" method="POST" enctype="multipart/form-data"> 
        <input type="submit" name="submit" value="Export as Text File"><br><br><br>
        <br>
</form>
</body>
</html>
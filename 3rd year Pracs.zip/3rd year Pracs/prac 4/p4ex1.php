<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Employees</h1>

    <?php
    //add database credentials
    require_once("config.php");
    //make connection to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Could not connect to the database");
    //issue query to instructions
    $query = "SELECT employeeNumber, lastName, firstName FROM employees";
    $result = mysqli_query($conn, $query) or die("could not retrive data");
    //start table
    echo "<table width=\"50%\" border=0>
            <tr bgcolor = \"#428bca\">
            <td>Name</td>
            <td>Details</td>
            <td>Update</td>
            <td>Delete</td>
            </tr>";
    //populate data in table rows
    while($row = mysqli_fetch_array($result)){
    echo "<tr>";
    echo "<td>" . $row['firstName'] . " " . $row['lastName'] . "</td>";
    echo "<td> <a href=\"display.php?id=" . $row['employeeNumber'] . "\">Details</a> </td>";
    echo "<td> <a href=\"update.php?id=" . $row['employeeNumber'] . "\">Update</a></td>";
    echo "<td> <a href=\"delete.php?id=" . $row['employeeNumber'] . "\" onclick =\"alert(\"Are you sure you want to delete: \" . $row[firstName] . $row[lastName] . \" ); \" \">Delete</a> ". "</td>";
    echo "</tr>";
    }
    //end table
    echo "</table>";
    //close connection
    mysqli_close($conn);
    ?>
</body>
</html>
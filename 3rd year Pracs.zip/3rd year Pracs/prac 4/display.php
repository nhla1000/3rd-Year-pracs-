<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //pass id
    $id = $_REQUEST['id'];
    //add database credentials
    require_once("config.php");
    //make connection to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Could not connect to the database");
    //issue query to instructions
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn, $query) or die("could not retrive data");
    //output data
    while ($row = mysqli_fetch_array($result)){
    echo "<h2>". $row['firstName'] . " " . $row['lastName'] . "</h2>";
    echo "<p>Job title: {$row['jobTitle']} </p>"; 
    echo "<p>Extention: {$row['extension']} </p>";
    echo "<p>eMail: {$row['email']}</p>";
    }
    //end connection 
    mysqli_close($conn);
    ?>
</body>
</html>
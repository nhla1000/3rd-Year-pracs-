<?php
//call id & elements from form
$id = $_REQUEST['id'];
$jobTitle = $_REQUEST['jobTitle'];
$extension = $_REQUEST['extention'];
$email = $_REQUEST['email'];
$officeCode = $_REQUEST['officeCode'];
$reportsTo = $_REQUEST['reportsTo'];
//credentials via config
require_once("config.php");
//connect to the database
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
    or die ("Error: could not connect to the database!!");
//issue instruction via query
$query = "UPDATE employees SET jobTitle = '$jobTitle', extension = '$extension',
email = '$email', officeCode = '$officeCode',
reportsTo = '$reportsTo'
WHERE employeeNumber = $id";
$result = mysqli_query($conn,$query) 
    or die ("Error: could not issue instruction!!");
//close connection
mysqli_close($conn);
//echo
echo "<p style=\"color: green\">The record was successfuly updated!!</p>"
?>
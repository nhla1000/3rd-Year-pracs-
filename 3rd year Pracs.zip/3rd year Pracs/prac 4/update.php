<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        //pass id
    $id = $_REQUEST['id'];
    //add database credentials
    require_once("config.php");
    //make connection to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Could not connect to the database");
    //issue query to instructions
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn, $query) or die("could not retrive data");
    //output data
    while ($row = mysqli_fetch_array($result)){
            //request information from the form
            $jobTitle = $row['jobTitle'];
            $extention = $row['extension'];
            $email = $row['email'];
            $officeCode = $row['officeCode'];
            $reportsTo = $row['reportsTo'];
    }
    //close connection
    mysqli_close($conn);
    ?>
    <form action="change.php" method="POST">
    <label for="idtitle"><strong>Job Title:</strong></label><br>
    <input type="text" name="jobTitle" value="<?php echo $jobTitle ?>" require><br>
    <label for="idextention">Extention:</label><br>
    <input type="text" name="extention" value="<?php echo $extention ?>" require><br>
    <label for="idemail">Email:</label><br>
    <input type="text" name="email" value="<?php echo $email ?>" require><br>
    <label for="idcode">Office Code:</label><br>
    <input type="text" name="officeCode" value="<?php echo $officeCode ?>" require><br>
    <label for="idreports">Reports To:</label><br>
    <input type="text" name="reportsTo" value="<?php echo $reportsTo ?>" require><br>
    <input type="hidden" name="id" value="<?php echo $id ?>">
    <input type="submit" name="submit" value="Update">
    </form>
    <?php
    ?>
</body>
</html>
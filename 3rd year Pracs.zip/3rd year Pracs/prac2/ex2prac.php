<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Laptop Categories</h1>
    <form action="ex2prac.php" method="POST">
        <label for="laptopprice">Laptop Price (Rands): </label>
        <input type="text" name="amount" id="idamount" required><br>
        <input type="submit" name="submit" value="Display Category">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //fetch the value posted by user
        $rands = $_REQUEST['amount'];
        //make conditions for the categories
        if ($rands > 0 && $rands <= 9999){
            echo "Your laptop falls into the <strong>Home</strong> category!";
        } 
        elseif ($rands >= 10000 && $rands <= 19999) {
            echo "Your laptop falls into the <strong>Mainstream</strong> category!";
        }
        elseif ($rands >= 20000 && $rands <= 29999) {
            echo "Your laptop falls into the <strong>High Performance</strong> category!";
        } else {
            echo "Your laptop falls into the <strong>Gaming</strong> category!";
        }
    }
    ?>
</body>
</html>
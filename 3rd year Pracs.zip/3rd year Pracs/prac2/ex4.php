<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //store data credentials
    $servername = "is3-dev.ict.ru.ac.za";
    $username = "G18M4049";
    $password = "G18M4049";
    $database = "g18m4049";
    //connect to database
    $connection = mysqli_connect($servername, $username, $password, $database) or die ("<h1><p style = \"color: red\">Cloud not connect to the databse</p><h3>");
    //instrutions
    $query = "SELECT* FROM Offices";
    $result = mysqli_query($connection, $query) or die ("<h1><p style = \"color: red\">Cloud not execute query !</p></h1>");
    //close connection
    mysqli_close($connection);
    ?>
</body>
</html>
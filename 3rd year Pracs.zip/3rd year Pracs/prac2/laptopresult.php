<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>
        Laptop Categories
    </h1>
    <form action="laptopresult.php" method="POST">
        <label for="text">Laptop Price (rands): </label>
        <input type="number" required size="6" name="laptop"><br>
        <input type="submit" value="Display Category" name="submit">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
    //request the information from the form
    $laptop = $_REQUEST['laptop'];
    //create conditions for laptop categories
    if($laptop <= 9999){
        echo "Your laptop falls into Home category!";
    } elseif($laptop >= 10000 && $laptop <= 19999){
        echo "Your laptop falls into Mainstream category!";
    } elseif($laptop >= 20000 && $laptop <= 29999){
        echo "Your laptop falls into High performance category!";
    } else{
        echo "Your laptop falls into Gaming category!";
    }
}

    ?>
</body>
</html>
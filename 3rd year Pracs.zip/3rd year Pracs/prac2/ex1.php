 <!DOCTYPE html>
 <html lang="en">
 <head>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Document</title>
 </head>
 <body>
     <h1>
         Due date calculator
     </h1>
     <br>
     <form action="ex1.php" method="POST">
         <label for="purchasedate">Purchase Date</label> <br>
         <input type="date" name="date" size="6" id="iddate"> <br>
         <br>
         <input type="submit" value="Calculate Due Date">
     </form>
     <?php
        echo "<h1>Payment due date</h1><br>"
        //request the date seleted from the form
        $date = $_REQUEST['iddate'];
        //add 30days to that date and write your output
        echo "This bill will be due on ". date("d-M-Y", strtotime("+30 days"));
        ?>
 </body>
 </html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Due date calculator</h1>
    <form action="ex1prac.php" method="POST">
        <label for="Purchase">Purchase Date:</label><br><br>
        <input type="date" id="iddate" name="day"><br><br>
        <input type="submit" name="submit" value="Calculate due date">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
            //first take the date from the input and give it a value
    $date = $_REQUEST['day'];
    //convert string to time
    $convert = strtotime($date);
    //add 30 days after converting string to time
    $newdate = strtotime("+30 days",$convert);
    //give the date a format
    $dateformat = date("d-M-Y",$newdate);
    //echo the date by adding 30 days
    echo "<h1>Payment due date</h1>
            This bill will be due on $dateformat";
    }
    ?>
</body>
</html>
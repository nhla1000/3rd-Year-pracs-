<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Names</h1>
    <form action="ex3prac.php" method="POST">
    <input type="text" name="username1" id="idusername" required><br>  
    <input type="text" name="username2" id="idusername" required><br>
    <input type="text" name="username3" id="idusername" required><br>
    <input type="text" name="username4" id="idusername" required><br>
    <input type="text" name="username5" id="idusername" required><br>
    <input type="text" name="username6" id="idusername" required><br>
    <input type="text" name="username7" id="idusername" required><br>
    <input type="text" name="username8" id="idusername" required><br>
    <input type="text" name="username9" id="idusername" required><br>
    <input type="text" name="username0" id="idusername" required><br><br>
    <input type="submit" name="submit" value="Display in table">
    </form>
    <style>
        table {
            width: 25%;
        }
        tr {
            background-color: lightblue;
        }
    </style>
    <?php
    if(isset($_REQUEST['submit'])){
        //start table
        echo "<table>";
        //use foreach to loop
        foreach ($_REQUEST as $value){
            echo "<tr>";
            echo "<td>$value</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    ?>
</body>
</html>
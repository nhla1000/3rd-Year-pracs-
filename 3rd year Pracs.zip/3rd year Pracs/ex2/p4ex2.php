<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        require_once("config.php");

        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
        or die("<h3 style=\"color:red;\">Could not connect to database!</h3>");

        $query = "SELECT employeeNumber, lastName, firstName FROM employees";
        $results = mysqli_query($conn, $query)
                or die("<h3 style=\"color:red;\">Could not execute query!</h3>");

        echo "<h3>Employees</h3>";

        echo "<table><tr style=\"Background-color: lightblue;\"><td>Name</td><td></td><td></td>";

        while ($row = mysqli_fetch_array($results)) {
            echo "<tr><td>{$row['firstName']} {$row['lastName']} </td>
            <td><a href=\"details.php?id={$row['employeeNumber']}\">Details</a></td>
            <td><a href=\"update.php?id={$row['employeeNumber']}\">Update</a></td></tr>";
        }

        mysqli_close($conn);
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <?php 
        $id = $_REQUEST['id'];

        require_once("config.php");

        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
        or die("<h3 style=\"color:red;\">Could not connect to database!</h3>");

        $query = "SELECT * FROM employees WHERE employeeNumber = $id";
        $results = mysqli_query($conn, $query)
                or die("<h3 style=\"color:red;\">Could not execute query!</h3>");

        $row = mysqli_fetch_array($results);

        echo "<h3>{$row['firstName']} {$row['lastName']}</h3> ";

        $title = $row['jobTitle'];
        $ext = $row['extension'];
        $email = $row['email'];
        $code = $row['officeCode'];
        $report = $row['reportsTo'];

        mysqli_close($conn);
    ?> 

    <form action="update.php" method="POST">
        <label for="title"><strong>Job Title:</strong></label><br>
       <!--  <select id="title" name="title" default="<?php echo $title ?>">
            <option value="">Job Titles</option>
            <option value="President">President</option>
            <option value="VP Sales">VP Sales</option>
            <option value="VP Marketing">VP Marketing</option>
            <option value="Sales Manager (APAC)">Sales Manager (APAC)</option>
            <option value="Sales Manager (EMEA)">Sales Manager (APAC)</option>
            <option value="Sales Manager (NA)">Sales Manager (NA)</option>
            <option value="Sales Rep">Sales Rep</option>
        </select> <br> -->
        <input type="jobTitle" id="email" name="jobTitle" required value="<?php echo $title ?>"><br>
        <label for="ext"><strong>Extension:</strong></label><br>
        <input type="text" id="ext" name="ext" pattern="[x]{1}[0-9]{3,4}" size="5" maxlength="5" required value="<?php echo $ext ?>"><br>
        <label for="email"><strong>Email:</strong></label><br>
        <input type="email" id="email" name="email" required value="<?php echo $email ?>"><br>
        <label for="code"><strong>Office code:</strong></label><br>
        <input type="text" id="code" name="code" size="5" required pattern=[0-9]{1} value="<?php echo $code ?>"><br>
        <label for="report"><strong>Reports to:</strong></label><br>
        <input type="text" id="report" name="report" size="5" required pattern=[0-9]{4}  value="<?php echo $report ?>"><br>
        <input type="hidden" id="id" name="id" value="<?php echo $id ?>">
        <br>
        <input type="submit" name="submit" value="Update Record">
    </form>

    <?php 

        if (isset($_REQUEST['submit'])) {
            require_once("config.php");

            $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("<h3 style=\"color:red;\">Could not connect to database!</h3>");

            $jobTitle = $_REQUEST['title'];
            $extension = $_REQUEST['ext'];
            $email = $_REQUEST['email'];
            $officeCode = $_REQUEST['code'];
            $reportsTo = $_REQUEST['report'];
            

            $query = "UPDATE employees SET jobTitle = '$jobTitle', extension = '$extension',
                        email = '$email', officeCode = '$officeCode',
                        reportsTo = '$reportsTo'
                        WHERE employeeNumber = $id";

            $results = mysqli_query($conn, $query)
                    or die("<h3 style=\"color:red;\">Could not execute query!</h3>");

            mysqli_close($conn);

            echo "<p style=\"color: green;\"> The record was successfully updated!</p>";

        }
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //request information from the form input
    
    $employeenumber = $_REQUEST['employeenumber'];
    $lastname = $_REQUEST['lastname'];
    $firstname = $_REQUEST['firstname'];
    $extention = $_REQUEST['extention'];
    $mail = $_REQUEST['email'];
    $code = $_REQUEST['officecode'];
    $reports = $_REQUEST['reportsto'];
    $title = $_REQUEST['jobtitle'];

    
    //add database creds
    require_once("config.php");
    // make connection to database or die if connection fails
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
    or die("ERROR: unable to connect to database!");
    //issue query instruction
    $query = "INSERT INTO employees(employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
                VALUES('$employeenumber', '$lastname', '$firstname', '$extention', '$mail', '$code', '$reports', '$title')";
    $result = mysqli_query($conn, $query) or die("ERROR: unable to execute query!");
    // close the connection to database
    echo "<h3 style>The new employee was added</h3>";

    mysqli_close($conn);

    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<style>
    table{
        border-collapse: collapse;
    }
    th{
        text-align: left;
    }
    tr:nth-child(even){
        background-color: grey;
    }
</style>
    <h1>
        Orders
    </h1><br>
    <form action="p3ex4.php" method="POST">
        <input type="submit" value="shipped" name="submit">
        <input type="submit" value="resolved" name="submit">
        <input type="submit" name="submit" id="idhold" value="hold">
        <input type="submit" name="submit" id="idcancelled" value="cancelled">
        <input type="submit" name="submit" value="disputed">
        <input type="submit" name="submit" value="process">
    </form>
    <?php
    if (isset($_REQUEST['submit'])){
        //add database creds
        require_once("config.php");
        // make connection to database or die if connection fails
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
            or die("could not connect to database");
        //issue query instructions
        $query = "";
        //use if/elseif to issue the correct query for the correct submit
        if($_REQUEST['submit'] == "shipped"){
            //query to request info from database
            $query = "SELECT * FROM orders WHERE status = 'Shipped'";
        } elseif($_REQUEST['submit'] == "resolved"){
            //query to request info from database
            $query = "SELECT * FROM orders WHERE status = 'Resolved'";
        } elseif($_REQUEST['submit'] == "hold"){
            //query to request info from database
            $query = "SELECT * FROM orders WHERE status = 'On Hold'";
        } elseif($_REQUEST['submit'] == "cancelled"){
            //query to request info from database
            $query = "SELECT * FROM orders WHERE status = 'Cancelled'";
        } elseif($_REQUEST['submit'] == "disputed"){
            //query to request info from database
            $query = "SELECT * FROM orders WHERE status = 'Disputed'";
        } elseif($_REQUEST['submit'] == "process"){
            //query to request info from database
            $query = "SELECT * FROM orders WHERE status = 'In Process'";
        }
        $result = mysqli_query($conn, $query) or die("ERROR: unable to execute query!");
        //heading
        //start with table
        echo "<table width=\"100%\" border=0>
                <tr bgcolor=\"#F97E13\">
                <th>Order Number</th>
                <th>Order Date</th>
                <th>Required Date</th>
                <th>Shipped Date/th>
                <th>Commets</th>
            </tr>";
        //populate table rows with data from database
        while ($row = mysqli_fetch_array($result)){
            echo "<tr>";
            echo "<td>" . $row['orderNumber'] ."</td>";
            echo "<td>" . $row['orderDate'] ."</td>";
            echo "<td>" . $row['requiredDate'] ."</td>";
            echo "<td>" . $row['shippedDate'] ."</td>";
            echo "<td>" . $row['comments'] . "</td>";
            echo "</tr>";
         }
         echo "</table>";
        // close the connection to database
        mysqli_close($conn);
    }
    ?>
</body>
</html>
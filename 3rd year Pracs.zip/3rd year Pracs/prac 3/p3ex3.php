<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Customers</h1><br>
    <form action="p3ex3.php" method="POST">
    <input type="submit" name="submit" value="Show Customers">
    </form>
</body>
<style>
    table{
        border-collapse: collapse;
    }
    th{
        text-align: left;
    }
    tr:nth-child(even){
        background-color: grey;
    }
</style>
    <?php
    if (isset($_REQUEST['submit'])){
        //add database creds
        require_once("config.php");
        // make connection to database or die if connection fails
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
            or die("could not connect to database");
        //issue query instructions
        $query = "SELECT * FROM customers ORDER BY customerName";
        $result = mysqli_query($conn, $query) or die("ERROR: unable to execute query!");
        //start with table
        echo "<table width=\"100%\" border=0>
                <tr bgcolor=\"#F97E13\">
                <th>Customer Name</th>
                <th>Contact Name</th>
                <th>Telephone</th>
                <th>Address/th>
                <th>City</th>
                <th>Country</th>
                <th>Credit Limit</th>
            </tr>";
        //populate table rows with data from database
        while ($row = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $row['customerName'] ."</td>";
            echo "<td>" . $row['contactFirstName'] . " " . $row['contactLastName'] . "</td>";
            echo "<td>" . $row['phone'] . "</td>";
            echo "<td>" . $row['addressLine1'] . " " . $row['addressLine2'] . "</td>";
            echo "<td>" . $row['city'] . "</td>";
            echo "<td>" . $row['country'] . "</td>";
            echo "<td>" . $row['creditLimit'] . "</td>";
            echo "</tr>";
         }
         echo "</table>";
        // close the connection to database
        mysqli_close($conn);
        }
    ?>
</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Add new employee</h1>
    <form action="p3ex1.php" method="POST">
        <label for="idemployeenumber">Employee Number:</label><br>
        <input type="number" name="employeenumber" required maxlength="4" size="25"><br>
        <label for="idlastname">Last Name:</label><br>
        <input type="text" name="lastname" required size="25"><br>
        <label for="idfirstname">First Name</label><br>
        <input type="text" name="firstname" size="25" required><br>
        <label for="idextention">Extention:</label><br>
        <input type="text" name="extention" size="25" required pattern="[a-z]{1}[0-9]{3,4}"><br>
        <label for="idemail">Email:</label><br>
        <input type="email" id="email" name="email" required size="25"><br>
        <label for="idcode">Office code:</label><br>
        <input type="number" name="officecode" size="25" maxlength="1" required><br>
        <label for="idreports">Reports:</label><br>
        <input type="number" name="reportsto" size="6" maxlength="4" required><br>
        <label for="idtitle">Job Title:</label><br>
        <select name="jobtitle" id="idtitle"><br><br>
            <option value="1">Sales Rep</option>
            <option value="2">Sales Manager</option>
            <option value="3">VP Marketing</option>
            <option value="4">VP Sales</option>
            <option value="5">President</option>
        </select><br><br><br>
        <input type="submit" name="submit" value="Add">
    </form>
</body>
<?php
    if(isset($_REQUEST['submit'])){
    
        //request information from the form input
        
        $employeenumber = $_REQUEST['employeenumber'];
        $lastname = $_REQUEST['lastname'];
        $firstname = $_REQUEST['firstname'];
        $extention = $_REQUEST['extention'];
        $mail = $_REQUEST['email'];
        $code = $_REQUEST['officecode'];
        $reports = $_REQUEST['reportsto'];
        $title = $_REQUEST['jobtitle'];

        
        //add database creds
        require_once("config.php");
        // make connection to database or die if connection fails
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
        or die("ERROR: unable to connect to database!");
        //issue query instruction
        $query = "INSERT INTO employees(employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
                    VALUES('$employeenumber', '$lastname', '$firstname', '$extention', '$mail', '$code', '$reports', '$title')";
        $result = mysqli_query($conn, $query) or die("ERROR: unable to execute query!");
        // close the connection to database
        echo "<h3 style>The new employee was added</h3>";

        mysqli_close($conn);

    }
?>
</html>
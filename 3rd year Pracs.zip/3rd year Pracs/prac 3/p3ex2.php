<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    if (isset($_REQUEST['submit'])){
        //request information from the form input
        $productline = $_REQUEST['productLine'];
        $description = $_REQUEST['textDescription'];
        $htmldescription = "<p>".$description."</p>";
        //make file name unique
        $picture = time() . $_FILES['image']['name'];
        // move the file to the upload folder
        $destination = "productlines/" . $picture;
        move_uploaded_file($_FILES['image']['tmp_name'], $destination);
        // add database credentials
        require_once("config.php");
        // make connection to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("ERROR: unable to connect to database!");
        // issue query instructions
        $query = "INSERT INTO productlines(productLine, textDescription, htmlDescription, image)
                    VALUE('$productline', '$description', '$htmldescription', '$picture')";
        $result = mysqli_query($conn, $query) or die("ERROR: unable to execute query!");
        // close the connection to database
        echo "<h2 style = \"color: blue;\">The new product line was added</h2>";

    }
    ?>
    <h1>Add new product line</h1><br>
    <form action="p3ex2.php" method="POST">
        <label for="idproduct">Product line:</label><br>
        <input type="text" name="productLine" size="19" required><br>
        <label for="iddescr">Description:</label><br>
        <input type="text" name="textDescription" size="30" style="height:60px;"><br>
        <label for="idpricture">Picture:</label><br>
        <input type="file" name="image" required><br><br>
        <input type="submit" value="Add" name="submit">
    </form>
</body>
</html>
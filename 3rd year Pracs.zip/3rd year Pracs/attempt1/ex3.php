<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //config
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
        or die ("Error could not connect to databse");
    //issue instrctions via query
    $query = "SELECT employeeNumber, lastName, firstName FROM employees";
    $result = mysqli_query($conn,$query) 
        or die ("Error: could not issue instruction");
    //echo table 
    echo "<table>
    <tr style=\"background-color: blue\">
        <th>Name</th>
        <th>Details</th>
        <th>Update</th>
        <th>Delete</th>
    </tr>";
    //while
    while ($row = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td><strong>{$row['firstName']} {$row['lastName']}</strong></td>";
        echo "<td><a href=\"details.php?id={$row['employeeNumber']}\">Details</a></td>";
        echo "<td><a href=\"update.php?id={$row['employeeNumber']}\">Update</a></td>";
        echo "<td><a href=\"delete.php?id={$row['employeeNumber']}\" <input onclick=\"return confirm('Are you sure you want to delete " . strtoupper($row['firstName']) . " " . strtoupper($row['lastName']) . "')\">Delete</a></td>";
        echo "</tr>";
    }
    echo "</table>";
    ?>
</body>
</html>
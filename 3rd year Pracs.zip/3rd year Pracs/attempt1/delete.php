<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //request id
    $emp_ID = $_REQUEST['id'];
    //credentials using config
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
        or die ("Error: could not conect to the database!!");
    //issue instruction via query
    $query = "DELETE FROM employees WHERE employeeNumber = $emp_ID";
    $result = mysqli_query($conn,$query) 
        or die ("Error: could not issue instruction!!!");
        //close connection
    mysqli_close($conn);
    //redirecting to the p4ex1.php page
    header("Location: ex3.php");
    ?>
</body>
</html>
<?php
//call the id
$id = $_REQUEST['id'];
//credentials via config
require_once("config.php");
//connect to the database
$conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
        or die ("Error: could not connect to the datase");
//issue instruction via query
$query = "SELECT * FROM employees WHERE employeeNumber = $id";
$result = mysqli_query($conn,$query) 
        or die ("Error: could not exwcute query");
//while
while ($row = mysqli_fetch_array($result))
{
    //echo 
    echo "<h1>{$row['firstName']} {$row['lastName']}</h1>";
    echo "<strong>Job Tittle: </strong><p>{$row['jobTitle']}</p>";
    echo "<strong>Extension: </strong><p>{$row['extension']}</p>";
    echo "<strong>eMail</strong><p>{$row['email']}</p>";
}
//close connection
mysqli_close($conn);
?>

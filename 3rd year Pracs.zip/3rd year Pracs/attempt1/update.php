<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
        //login credentials via config
        require_once("config.php");
        //call the info from the form & id
        $id = $_REQUEST['id'];
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
                or die ("Error: could not connect to database");
        //issue instruction via query
        $query = "SELECT * FROM employees WHERE employeeNumber = $id";
        $result = mysqli_query($conn,$query) 
                or die ("Error: could not execute instruction");
        //use while statement to call values in the form
        while ($row = mysqli_fetch_array($result)){

            $jobTitle = $row['jobTitle'];
            $Extension = $row['extension'];
            $eMail = $row['email'];
            $OfficeCode = $row['officeCode'];
            $ReportsTo = $row['jobTitle'];
        }
        //close connection
        mysqli_close($conn); 
    ?>
    <form action="change.php" method="POST">
        <label for="jobtitle">Job Title:</label><br>
        <input type="text" name="jobtitle" id="jobtitle" value="<?php echo $jobTitle; ?>" required><br>
        <label for="ext">Extension:</label><br>
        <input type="text" name="Extension" id="extension" pattern="[x]{1}[0-9]{3,4}" value="<?php echo $Extension; ?>" required><br>
        <label for="mail">eMail:</label><br>
        <input type="email" name="eMail" id="email" value="<?php echo $eMail; ?>" required><br>
        <label for="officecode">Office Code:</label><br>
        <input type="text" name="offcode" id="offcode" maxlength="1" value="<?php echo $OfficeCode; ?>" required><br>
        <label for="jobtitle">Reports to:</label><br>
        <input type="text" name="report" id="report" value="<?php echo $ReportsTo; ?>" required><br><br>
        <input type="hidden" name="id" id="hidden" value="<?php echo $_REQUEST['id']; ?>">
        <input type="submit" name="submit" value="Update record">
    </form>
    
</body>
</html>
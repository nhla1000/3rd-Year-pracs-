<?php
//credentals
define("SERVERNAME","is3-dev.ict.ru.ac.za");
define("USERNAME","G18M4049");
define("PASSWORD","G18M4049");
define("DATABASE","g18m4049");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <?php
    //call id used 
    $id = $_REQUEST['id'];
    //credentials
    require_once("config.php");
    //connect to DB
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to DB!!");
    //issue instruction via query
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query)
            or die("Error: could not execute instruction!!");
    //use while to echo 
    while($row = mysqli_fetch_array($result)){
        echo "<h1>{$row['firstName']} {$row['lastName']}</h1>";
        echo "<p><strong>Job Title: </strong>{$row['jobTitle']}</p><br>";
        echo "<p><strong>Extension: </strong>{$row['extension']}</p><br>";
        echo "<p><strong>eMail: </strong>{$row['email']}</p>";
    }
    mysqli_close($conn);
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //store vairables from the form
    $id = $_REQUEST['id'];
    $jobTitle = $_REQUEST['jobTitle'];
    $extension = $_REQUEST['extension'];
    $email = $_REQUEST['email'];
    $officeCode = $_REQUEST['officeCode'];
    $reportsTo = $_REQUEST['reportsTo'];
    //credentials via config
    require_once("config.php");
    //connect to DB
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to DB!!");
    //issue instructions
    $query = "UPDATE employees SET jobTitle = '$jobTitle', extension = '$extension',
    email = '$email', officeCode = '$officeCode',
    reportsTo = '$reportsTo'
    WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query)
            or die("Error: could not execute query!!");
    //close connecton
    mysqli_close($conn);
    //display message
    echo "<h3 style=\"color:green\">Updated!!!!!!!!!!</h3>";
    ?>
</body>
</html>
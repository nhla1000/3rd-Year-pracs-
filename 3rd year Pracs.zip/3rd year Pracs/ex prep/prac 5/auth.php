<?php
require_once("secure.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //start session
    session_start();
    //store values from form
    $user = $_REQUEST['username'];
    $pass = $_REQUEST['password'];
    //use if to check if login details are correct 
    if($user == "Thabo" && $pass == "123abc"){
        //if correct then
        $_SESSION['access'] = "yes";
        $_SESSION['user'] = $user;

        //redirect user 
        header("Location:ex2.php");
    }
    else {
        header("Location:login.html");
    }
    ?>
</body>
</html>
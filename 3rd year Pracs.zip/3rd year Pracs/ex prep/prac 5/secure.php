
    <?php
    //start sesion
    session_start();
    //if
    if(!isset($_SESSION['access'])){
        header("Location: login.html");
    }
    ?>

<?php
require_once("secure.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Search Customer Credit Limit</h1>
    <h3>Welcome <?php echo $_SESSION['user'] ?> (<a href="logout.php">logout</a>)</h3>
    <form action="ex2.php" method="POST">
        <input type="search" name="search">
        <input type="submit" name="submit" value="Go">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //store variables from form
        $search = $_REQUEST['search'];
        //credentials
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to database!!");
        //issue instruction via query
        $query = "SELECT customerNumber, customerName FROM customers
        WHERE customerName LIKE '%$search%'
        ORDER BY customerName ASC";
        $result = mysqli_query($conn,$query) 
                or die("Error: could not execute query!!");
        //display
        echo "<ol>";
        //while to call calums from Db
        while($row = mysqli_fetch_array($result)){
            echo "<li>";
            echo "<a href=\"credit.php?id={$row['customerNumber']}\">{$row['customerName']}</a>";
            echo "</li>";
        }
    }
    ?>
</body>
</html>
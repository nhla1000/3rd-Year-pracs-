<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id
    $cust_ID = $_REQUEST['id'];
    //credentials
    require_once("config.php");
    //connect to DB
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to DB!!!");
    // issue instruction via query
    $query  = "SELECT customerName, creditLimit FROM customers WHERE customerNumber =
    $cust_ID";
    $result = mysqli_query($conn,$query) 
            or die("Error: could not execute instruction!!");
    //use while to fetch info
    while($row = mysqli_fetch_array($result)){
        $name = $row['customerName'];
        $credit = $row['creditLimit'];
    }
    echo "<h1>$name</h1>";
    echo "<p>Credit limit: R".number_format($credit,0)."</p>";
    mysqli_close($conn);
    ?>
    
</body>
</html>
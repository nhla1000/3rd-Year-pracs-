<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Customer Credit limiy</h1>
    <form action="ex5.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Export as Text File">
    </form>
    <?php
    //self ref form 
    if(isset($_REQUEST['submit'])){
        //credentials via config
        require_once("config.php");
        //connect to databse
        $conn = mysqli_connect(SERVERNAME,USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to DB!!");
        //issue instruction via query
        $query = "SELECT customerName, creditLimit FROM customers ORDER BY customerName ASC";
        $result  = mysqli_query($conn,$query)
                or die ("Error: could not execute query!!");
        //provide the exported file a name
        $filename = "credit.txt";
        //open the file
        $file = fopen($filename,"a") or die("error: could not open file!!");
        //while to call coloums from DB
        while($row = mysqli_fetch_array($result)){
            $text = $row['customerName']." = R".$row['creditLimit']."\n";
            fwrite($file,$text);
        }
        //close file
        fclose($file);
        //close connectiom
        mysqli_close($conn);
        //display message
        echo "<h2 style=\"color:green\">Exported succsessfuly!!</h2>";
    }
    ?>
</body>
</html>
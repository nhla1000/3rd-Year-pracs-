<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new employee</h1>
    <form action="ex1.php" method="POST">
        <label for="employee">Employee Number:</label><br>
        <input type="text" name="empnum" maxlength="4" required><br>
        <label for="lastname">Last Name:</label><br>
        <input type="text" name="lname" required><br>
        <label for="firstname">First Name:</label><br>
        <input type="text" name="fname" required><br>
        <label for="extension">Extension:</label><br>
        <input type="text" name="ext" maxlength="5" pattern="[x]{1}[0-9]{3,4}" required><br>
        <label for="email">eMail:</label><br>
        <input type="email" name="email" required><br>
        <label for="officecode">Office Code:</label><br>
        <input type="text" name="off" maxlength="1" required><br>
        <label for="reports">Reports To:</label><br>
        <input type="text" name="report" maxlength="4" required><br>
        <label for="jobtitle">Job Title</label><br>
        <select name="job" id="job">
            <option value="President">President</option>
            <option value="VP Marketing">VP Marketing</option>
            <option value="VP Sales">VP Sales</option>
            <option value="Sales Manager (APAC)">Sales Manager (APAC)</option>
            <option value="Sale Manager (EMEA)">Sale Manager (EMEA)</option>
            <option value="Sales Manager (NA)">Sales Manager (NA)</option>
            <option value="Sales Rep">Sales Rep</option>
        </select><br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    //selff ref
    if(isset($_REQUEST['submit'])){
        //store variables from form
        $empnum = $_REQUEST['empnum'];
        $lname = $_REQUEST['lname'];
        $fname = $_REQUEST['fname'];
        $ext = $_REQUEST['ext'];
        $email = $_REQUEST['email'];
        $off = $_REQUEST['off'];
        $report = $_REQUEST['report'];
        $job = $_REQUEST['job'];
        //credentials via config
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to databse!!");
        //isssue query via instruction
        $query = "INSERT INTO employees(employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
        VALUE('$empnum', '$lname', '$fname', '$ext', '$email', '$off', '$report', '$job')";
        $result = mysqli_query($conn,$query)
                or die("Error: Could not execute query!!");
        //close connection
        mysqli_close($conn);
        //display message
        echo "<h3 style=\"color:green\">The employee was added !!</h3>";
    }
    ?>
</body>
</html>
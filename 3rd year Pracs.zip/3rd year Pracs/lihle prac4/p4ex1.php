<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
    //import dataase credentials
    require_once("config.php");

    //make connection to the database
    $conn = mysqli_connect($servername, $username, $password, $database) or die("ERROR: Unable to connect to the database!");

    //issue query instructions 
    $query = "SELECT employeeNumber, lastName, firstName FROM employees";
    $result = mysqli_query($conn, $query) or die("ERROR: Unable to view details!");


    //display headings 
    echo "<h3>Employee</h3>";
    echo "<table>
        <tr bgcolor=\"lightblue\">
       <th>Name </th>
        <th> </th>
        <th> </th>
        <th> </th>
   </tr>";

    // populate table row with data from database
    while ($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>{$row['firstName']} {$row['lastName']}</td>";
        echo "<td><a href=\"details.php?id={$row['employeeNumber']}\">Details</a></td>";
        echo "<td><a href=\"update.php?id={$row['employeeNumber']}\">Update</a></td>";
        echo "<td> <a href=\"delete.php?id={$row['employeeNumber']}\" 
        <input onclick=\"return confirm('Are you sure you want to delete " . strtoupper($row['firstName']) . " " . strtoupper($row['lastName']) . "?');\">Delete</a>" . "</td>";
        echo "</tr>";
    }
    // end table
    echo "</table>";
    //close the connection yo database
    mysqli_close($conn);
    ?>

</body>

</html>
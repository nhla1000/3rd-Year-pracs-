 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php

    //import dataase credentials
    require_once("config.php");

     // store the id from the previous page
    $id = $_REQUEST['id'];
    $jobTitle = $_REQUEST['jobTitle'];
    $extension = $_REQUEST['extension'];
    $email = $_REQUEST['email'];
    $officeCode = $_REQUEST['officeCode'];
    $reportsTo = $_REQUEST['Reportsto'];
   
     //make connection to the database
    $conn = mysqli_connect($servername, $username, $password, $database) or die("ERROR: Unable to connect to the database!");

    //issue query instructions
    $query = "UPDATE employees SET jobTitle = '$jobTitle', extension = '$extension',
    email = '$email', officeCode = '$officeCode',
    reportsTo = '$reportsTo'
    WHERE employeeNumber = $id";
    
    $result = mysqli_query($conn, $query) or die("ERROR: Unable to edit");

    // populate table row with data from database
    mysqli_close($conn);

    //dispaly success 
    echo "<strong style=\" color: blue\"> The record was successfully updated! </strong>"




    ?>
</body>
</html>
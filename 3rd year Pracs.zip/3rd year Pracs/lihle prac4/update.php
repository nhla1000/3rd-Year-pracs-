<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //import dataase credentials
    require_once("config.php");

    // store the id from the previous page 
    $id = $_REQUEST['id'];

    //make connection to the database
    $conn = mysqli_connect($servername, $username, $password, $database) or die("ERROR: Unable to connect to the database!");

    //issue query instructions
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn, $query) or die("ERROR: Unable to edit");

    // populate table row with data from database
    while($row = mysqli_fetch_array($result)){

        $jobTitle = $row['jobTitle'];
        $Extension = $row['extension'];
        $eMail = $row['email'];
        $OfficeCode = $row['officeCode'];
        $ReportsTo = $row['reportsTo'];
    }
    // close the connection to database 
    mysqli_close($conn);

    ?>
    <form action="change.php" method="POST">
        <label for="JobTitle">Job Title:</label><br>
        <input type="text" name="jobTitle" id="jobTitle" value="<?php echo $jobTitle; ?>" size="25" required><br>
        <label for="extension">Extension:</label><br>
        <input type="text" name="extension"  id="extension" value="<?php echo $Extension; ?>" size="25" maxlength="5" pattern="[x]+[0-9]{3,4}" required> <br>
        <label for="email">eMail:</label><br>
        <input type="text" name="email" id="email" value="<?php echo $eMail; ?>" size="25" required><br>
        <label for="Officecode">Office code:</label><br>
        <input type="text" name="officeCode" id="officeCode" value="<?php echo $OfficeCode; ?>" maxlength="1" size="5" required><br>
        <label for="Reportsto">Reports to:</label><br>
        <input type="text" name="Reportsto" id="Reportsto" value="<?php echo $ReportsTo; ?>" maxlength="4" size="5" required><br><br>
        <input type="hidden" name="id" id="id" value="<?php echo $_REQUEST['id']; ?>">
        <input type="submit" name="submit" value="Update Record">
       

    </form>
    
</body>
</html>

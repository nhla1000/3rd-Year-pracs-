<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // store the id from the previous page 
    $emp_ID = $_REQUEST['id'];

    //import database credentials 
    require_once("config.php");

    //make connection to the database 
    $conn = mysqli_connect($servername, $username, $password, $database) or die("ERROR: Unable to connect to the database!");

    //issue query instructions 
    $query = "DELETE FROM employees WHERE employeeNumber = $emp_ID";
    $result = mysqli_query($conn, $query) or die('ERROR: Unable to delete the employee');

    // close the connection to database 
    mysqli_close($conn);

    //redirecting to the p4ex1.php page
    header("Location: p4ex1.php");
    ?>
</body>
</html>
    <?php
    $servername = "is3-dev.ict.ru.ac.za";
    $username = "G19M4974";
    $password = "G19M4974";
    $database  = "g19m4974";
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //make the string 
    $string = "apple banana cherry";
    //use tring replace
    $replace = str_replace("a","x",$string);
    //echo this
    echo "$string <br>
            $replace"
    ?>
</body>
</html>
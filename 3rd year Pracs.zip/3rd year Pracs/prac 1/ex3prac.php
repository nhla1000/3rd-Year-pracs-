<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <style>
        table {
            border: 1px solid;
            padding: 8px;
            text-align: center;
        } 
        th td {
            border: 1px solid;
        }
    </style>
    <?php
    //create vars
    $lb = 181;
    $stone = intval($lb/14);
    $remainder = $lb%14;
    $kilogram = round($lb*0.453592,1);
    //echo the table
    echo "<table>
    <tr>
        <th>Pounds</th>
        <th>Stone/Pounds</th>
        <th>Kilograms</th>
    </tr>
    <tr>
        <td>$lb</td>
        <td>$stone - $remainder</td>
        <td>$kilogram</td>
    </tr>
</table>"
    ?>
</body>
</html>
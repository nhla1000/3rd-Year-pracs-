<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      table, th, td {
        border: solid 1px black;
        border-collapse: collapse;
        width: auto;
      }
    </style>
</head>
<body>
    <?php
        // create a value for pounds 
        $var1 = 181;
        //convert pounds to stone
        $stone = intval($var1/14);
        //convert pounds to kg
        $kg =  round($var1* 0.453592, 1);
        //remainder
        $remainer = $var1%14;
        //output
        echo "<table>
        <tr>
          <th>
            Pounds
          </th>
          <th>
            Stone
          </th>
          <th>
            Kilogram
          </th>
        </tr>
        <tr>
        <td>$var1 lb</td>
        <td>$stone st - $remainer st</td>
        <td>$kg kg</td>
      </tr>
      </table>"
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //create a var to store the two numbers
    $num1 = 100;
    $num2 = 200;
    //do calculations
    $sum = $num1 + $num2;
    $diff = $num1 - $num2;
    $pro = $num1 * $num2;
    //echo the  calculations
    echo "Sum = $sum <br>
            Difference = $diff <br>
            Product = $pro" 
    ?>
</body>
</html>
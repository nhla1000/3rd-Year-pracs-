<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //create a variable
$var = "apple banana cherry";
//use the str replace funtion
$string = str_replace("a" ,"x" ,$var);
//document write
echo "$var <br> $string ";
    ?> 
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new product line</h1>
    <form action="ex2.php" method="POST" enctype="multipart/form-data">
        <label for="product">Product line: </label><br>
        <input type="text" name="prodline" required><br>
        <label for="description">Description: </label><br>
        <textarea name="des" id="des" cols="30" rows="10" required></textarea><br>
        <label for="picture">Picture: </label><br>
        <input type="file" name="img" required><br>
        <br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //call info from form
        $proline = $_REQUEST['prodline'];
        $descri = $_REQUEST['des'];
        $htmldescri = "<p>".$descri."</p>";
        //picture
        $picture = time().$_FILES['img']['name'];
        //destination
        $destination = "images/".$picture;
        move_uploaded_file($_FILES['img']['tmp_name'],$destination); 
        //credentials via config
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
                or die ("Error: could not connect to database!!");
        //issue instruction via query
        $query = "INSERT INTO productlines(productLine, textDescription, htmlDescription, image)
        VALUE('$proline', '$descri', '$htmldescri', '$picture')";
        $result = mysqli_query($conn,$query) 
                or die ("Error: could not execute query!!");
        //close connection
        mysqli_close($conn);
        //echo success
        echo "Product was added successfully";
    }
    ?>
</body>
</html>
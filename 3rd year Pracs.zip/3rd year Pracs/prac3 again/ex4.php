<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <h1>Orders</h1>
    <form action="ex4.php" method="GET">
        <input type="submit" name="submit" value="Shipped">
        <input type="submit" name="submit" value="Resolved">
        <input type="submit" name="submit" value="On Hold">
        <input type="submit" name="submit" value="Cancelled">
        <input type="submit" name="submit" value="Dispatched">
        <input type="submit" name="submit" value="In Process">
    </form>
    <br>
    <?php
    if(isset($_REQUEST['submit'])){
        //credentials via php
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die ("Error: could not connect to database!!");
        //issue instruction via query with conditions
        $query = "";
        if ($_REQUEST['submit'] == 'Shipped'){
            $query = "SELECT * FROM orders WHERE status = 'Shipped'";
        }
        elseif ($_REQUEST['submit'] == 'Resolved'){
            $query = "SELECT * FROM orders WHERE status = 'Resolved'";
        }
        elseif ($_REQUEST['submit'] == 'On Hold'){
            $query = "SELECT * FROM orders WHERE status = 'On Hold'";
        }
        elseif ($_REQUEST['submit'] == 'Cancelled'){
            $query = "SELECT * FROM orders WHERE status = 'Cancelled'";
        }
        elseif ($_REQUEST['submit'] == 'Dispatched'){
            $query = "SELECT * FROM orders WHERE status = 'Disputed'";
        }
        elseif($_REQUEST['submit'] == 'In Process'){
            $query = "SELECT * FROM orders WHERE status = 'In Process'";
        }
        $result = mysqli_query($conn,$query) 
            or die ("error: could not execute query!!");
        //echo table headings
        echo "<table>
        <tr style=\"background-color: #FFC0CB\">
            <th>Order Number</th>
            <th>Order Dtae</th>
            <th>Required Date</th>
            <th>Shipped Date</th>
            <th>Date Comment</th>
            <th>Customer Number</th>
        </tr>";
        //echo using while for the coloums we want to call
        while ($row = mysqli_fetch_array($result)){
            echo "<tr class=\"tr\">";
                echo "<td>{$row['orderNumber']}</td>";
                echo "<td>{$row['orderDate']}</td>";
                echo "<td>{$row['requiredDate']}</td>";
                echo "<td>{$row['shippedDate']}</td>";
                echo "<td>{$row['comments']}</td>";
                echo "<td>{$row['customerNumber']}</td>";
            echo "</tr>";
        }
        //close table
        echo "</table>";
        //close connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>
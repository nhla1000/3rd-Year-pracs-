<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new employee</h1>
    <form action="ex1.php" method="POST">
        <label for="employeenum">Employee Number:</label><br>
        <input type="text" name="empnum" maxlength="4" required><br>
        <label for="lastname">Last Name:</label><br>
        <input type="text" name="lastname" required><br>
        <label for="firstname">First Name</label><br>
        <input type="text" name="firstname" required><br>
        <label for="extension">Extension:</label><br>
        <input type="text" name="ext" required pattern="[x]{1}[0-9]{3,4}"><br>
        <label for="email">Email:</label><br>
        <input type="email" name="eml" required><br>
        <label for="officecode">Office Code:</label><br>
        <input type="text" name="offcode" maxlength="1" required><br>
        <label for="reportsto">Reports to:</label><br>
        <input type="text" name="reports" maxlength="4" required><br>
        <select name="job" id="idjob">
            <option value="President">President</option>
            <option value="VP Sales">VP Sales</option>
            <option value="VP Marketing">VP Marketing</option>
            <option value="Sales Manager (APAC)">Sales Manager (APAC)</option>
            <option value="Sale Manager (EMEA)">Sale Manager (EMEA)</option>
            <option value="Sales Manager (NA)">Sales Manager (NA)</option>
            <option value="Sales Rep">Sales Rep</option>
        </select><br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //give form inputs values
        $employee = $_REQUEST['empnum'];
        $lname = $_REQUEST['lastname'];
        $fname = $_REQUEST['firstname'];
        $exten = $_REQUEST['ext'];
        $mail = $_REQUEST['eml'];
        $office = $_REQUEST['offcode'];
        $rept = $_REQUEST['reports'];
        $title = $_REQUEST['job'];
        //credentials via config
        require_once("config.php");
        //connect
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
                or die ("Could not connect to the database!");
        //issue intrustions
        $query = "INSERT INTO employees(employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
            VALUE('$employee', '$lname', '$fname', '$exten', '$mail', '$office', '$rept', '$title')";
        $result = mysqli_query($conn,$query) 
            or die ("error: could not execute instruction");
        //close connection
        mysqli_close($conn);
        //echo if successull
        echo "<p><strong>Employee was added successfully!!</strong></p>";
    }
    ?>
</body>
</html>
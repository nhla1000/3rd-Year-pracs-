<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new employee</h1>
    <form action="ex1.php" method="POST">
        <label for="idemployeenumber">Employee Number:</label><br>
        <input type="number" name="employeenumber" required maxlength="4" size="25"><br>
        <label for="idlastname">Last Name:</label><br>
        <input type="text" name="lastname" required size="25"><br>
        <label for="idfirstname">First Name</label><br>
        <input type="text" name="firstname" size="25" required><br>
        <label for="idextention">Extention:</label><br>
        <input type="text" name="extention" size="25" required pattern="[a-z]{1}[0-9]{3,4}"><br>
        <label for="idemail">Email:</label><br>
        <input type="email" id="email" name="email" required size="25"><br>
        <label for="idcode">Office code:</label><br>
        <input type="number" name="officecode" size="25" maxlength="1" required><br>
        <label for="idreports">Reports:</label><br>
        <input type="number" name="reportsto" size="6" maxlength="4" required><br>
        <label for="idtitle">Job Title:</label><br>
        <select name="jobtitle" id="idtitle"><br><br>
            <option value="1">Sales Rep</option>
            <option value="2">Sales Manager</option>
            <option value="3">VP Marketing</option>
            <option value="4">VP Sales</option>
            <option value="5">President</option>
        </select><br><br><br>
        <input type="submit" name="submit" value="Add">
    </form>
</body>
<?php
    //self ref form
    if(isset($_REQUEST['submit'])){
        //store values from form
        $employeeNumber = $_REQUEST['employeenumber'];
        $lastName = $_REQUEST['lastname'];
        $firstName = $_REQUEST['firstname'];
        $extension = $_REQUEST['extention'];
        $email = $_REQUEST['email'];
        $officeCode = $_REQUEST['officecode'];
        $reportsTo = $_REQUEST['reportsto'];
        $jobTitle = $_REQUEST['jobtitle'];
        //require once config
        require_once("config.php");
        //connect to databse
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to DATABASE!!");
        //issue instruction via query
        $query = "INSERT INTO employees(employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
                    VALUES('$employeeNumber', '$lastName', '$firstName', '$extension', '$email', '$officeCode', '$reportsTo', '$jobTitle')";
        $result = mysqli_query($conn,$query) 
                or die("Error:could not execute query!!");
        //close connect and display message
        echo "<h2 style=\"color:green\">The new employee was recored add!!!</h2>";
        mysqli_close($conn);
    }
    ?>
</html>
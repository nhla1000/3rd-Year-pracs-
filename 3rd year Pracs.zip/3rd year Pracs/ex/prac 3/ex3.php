<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Customers</h1>
    <form action="ex3.php" method="POST">
        <input type="submit" name="submit" value="Show customers"><br>
    </form><br>
    <?php
    //self ref
    if(isset($_REQUEST['submit'])){
        //credentials via php
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to database!!");
        //issue instruction via php
        $query = "SELECT * FROM customers ORDER BY customerName";
        $result = mysqli_query($conn,$query) or die ("Error: could not execute query!!");
        //display table header
        echo "<table>
        <tr style=\"background-color:#FFA500\">
            <th>Customer Name</th>
            <th>Contact Name</th>
            <th>Telephone</th>
            <th>Address</th>
            <th>City</th>
            <th>Country</th>
            <th>Credit Limit</th>
        </tr>";
        //use while to call info from database
        while($row = mysqli_fetch_array($result)){
            echo "<tr class=\"tr\">";
            echo "<td>{$row['customerName']}</td>";
            echo "<td>{$row['contactFirstName']} {$row['contactLastName']}</td>";
            echo "<td>{$row['phone']}</td>";
            echo "<td>{$row['addressLine1']}</td>";
            echo "<td>{$row['city']}</td>";
            echo "<td>{$row['country']}</td>";
            echo "<td>{$row['creditLimit']}</td>";
            echo "</tr>";
        }
        //close table
        echo "</table>";
        //close connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>
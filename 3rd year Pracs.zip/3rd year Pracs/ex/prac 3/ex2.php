<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new product line</h1>
    <form action="ex2.php" method="POST" enctype="multipart/form-data">
        <label for="product">Product line:</label><br>
        <input type="text" name="prod" required><br>
        <label for="description">Description:</label><br>
        <textarea name="desc" id="desc" cols="30" rows="10"></textarea><br>
        <label for="picture">Picture</label><br>
        <input type="file" name="picture" required><br><br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    //self ref form
    if(isset($_REQUEST['submit'])){
        //store variables from form
        $productLine = $_REQUEST['prod'];
        $textDescription = $_REQUEST['desc'];
        $htmlDescription = "<p>$textDescription</p>";
        //picture
        $picture = time().$_FILES['picture']['name'];
        //give picture a destination
        $destination = "image/".$picture;
        move_uploaded_file($_FILES['picture']['tmp_name'],$destination);
        //credentials
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die ("Error: could not connect to Database!!");
        //issue instructon via query
        $query = "INSERT INTO productlines(productLine, textDescription, htmlDescription, image)
                    VALUE('$productLine', '$textDescription', '$htmlDescription', '$picture')";
        $result = mysqli_query($conn,$query)
                    or die("Error: could not execute query!");
        //close connection
        mysqli_close($conn);
        //display message
        echo "<h1>The new product was added!!</h1>";
    }
    ?>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id from prev page
    $id = $_REQUEST['id'];
    //credentials
    require_once("config.php");
    //credentals
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to databasee!!");
    //issue instruction
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query)
            or die("Error: could not execute query!!");
    //use while to call info from database
    while($row = mysqli_fetch_array($result)){
        $jobTitle = $row['jobTitle'];
        $extension = $row['extension'];
        $email = $row['email'];
        $officeCode = $row['officeCode'];
        $reportsTo = $row['reportsTo'];
        $firstName = $row['firstName'];
        $lastName = $row['lastName'];
    }
    //close connection
    mysqli_close($conn);
    ?>
    <h1><?php echo $firstName . $lastName ?></h1>
    <form action="change.php" method="POST">
        <label for="job">Jobtitle</label><br>
        <input type="text" name="jobTitle" value="<?php echo $jobTitle ?>" required><br>
        <label for="Extension">Extension</label><br>
        <input type="text" name="extension" value="<?php echo $extension ?>" pattern="[x]{1}[0-9]{3,4}" maxlength="5" required><br>
        <label for="Email">Email</label><br>
        <input type="email" name="email" value="<?php echo $email ?>" required><br>
        <label for="Office">Office Code</label><br>
        <input type="text" name="officeCode" value="<?php echo $officeCode ?>" maxlength="1" required><br>
        <label for="Reports">Reports To</label><br>
        <input type="text" name="reportsTo" value="<?php echo $reportsTo ?>" maxlength="4" required><br>
        <input type="hidden" name="id" value="<?php echo $id ?>">
        <input type="submit" name="submit" value="Update Record">
    </form>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id from previous page & store values from form
        $id = $_REQUEST['id'];
        $jobTitle = $_REQUEST['jobTitle'];
        $extension = $_REQUEST['extension'];
        $email = $_REQUEST['email'];
        $officeCode = $_REQUEST['officeCode'];
        $reportsTo = $_REQUEST['reportsTo'];
        //credentials via config
        require_once("config.php");
        //connect to my database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die ("Error: could not connect to Database!!");
        //issue instruction via query
        $query = "UPDATE employees SET jobTitle = '$jobTitle', extension = '$extension',
            email = '$email', officeCode = '$officeCode',
            reportsTo = '$reportsTo'
            WHERE employeeNumber = $id";
        //result
        $result = mysqli_query($conn,$query)
                or die("Error: could not execute query!!");
        //display message after closing connection
        mysqli_close($conn);
        //display message
        echo "<h2 style=\"color:green\">The record was updatted!!!</h2>";
    ?>
</body>
</html>
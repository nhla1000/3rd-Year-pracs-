<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $id=$_REQUEST['id'];
    //require once
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to Database!!");
    //issue instruction via query
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query)
            or die("Error: could not execute query!!!");
    //use while to echo result
    while($row = mysqli_fetch_array($result)){
        echo "<h1>{$row['firstName']} {$row['lastName']}</h1>";
        echo "<p><strong>Jobe Title: </strong>{$row['jobTitle']}</p>";
        echo "<p><strong>Extension: </strong>{$row['extension']}</p>";
        echo "<p><strong>eMail: </strong>{$row['email']}</p>";
    }
    //close connection
    mysqli_close($conn);
    ?>
</body>
</html>
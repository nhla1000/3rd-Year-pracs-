<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id from previous page
    $id = $_REQUEST['id'];
    //credentials
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to database!!");
    //issue instruction via query
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query)
            or die("Error: could not issue instructions!!");
    //use while to call data from database
    while($row = mysqli_fetch_array($result)){
        $jobTitle = $row['jobTitle'];
        $extension = $row['extension'];
        $email = $row['email'];
        $officeCode = $row['officeCode'];
        $reportsTo = $row['reportsTo'];
        $fname = $row['firstName'];
        $lname = $row['lastName'];
    }
    ?>
    <h1><?php echo $fname." ".$lname ?></h1>
    <form action="change.php" method="POST">
        <label for="job">Job Title</label><br>
        <input type="text" name="jobTitle" value="<?php echo $jobTitle ?>" required><br>
        <label for="ext">Extension</label><br>
        <input type="text" name="extension" value="<?php echo $extension ?>" pattern="[a-z]{1}[0-9]{3,4}" maxlength="5" required><br>
        <label for="mail">Email</label><br>
        <input type="email" name="email" value="<?php echo $email ?>" required><br>
        <label for="off">Office Code</label><br>
        <input type="text" name="officeCode" value="<?php echo $officeCode ?>" maxlength="1" required><br>
        <label for="reports">Reports To</label><br>
        <input type="text" name="reportsTo" value="<?php echo $reportsTo ?>" maxlength="4" required><br>
        <input type="hidden" name="id" value="<?php echo $id ?>"><br>
        <input type="submit" name="submit" value="Update Record">
    </form>
</body>
</html>
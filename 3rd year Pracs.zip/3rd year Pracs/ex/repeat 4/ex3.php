<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <?php
    require_once("config.php");
    //connect to DB
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to DB!!");
    //issue instruction via query
    $query = "SELECT employeeNumber, lastName, firstName FROM employees";
    $result = mysqli_query($conn,$query)
            or die("Error: could not execute instruction!!");
    //start displaying table header
    echo "    <table>
    <tr style=\"background-color:#FFA500\">
        <th>Name</th>
        <th>Details</th>
        <th>Update</th>
        <th>Delete</th>
    </tr>";
    //use while to display info from database
    while($row = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>{$row['firstName']} {$row['lastName']}</td>";
        echo "<td><a href=\"details.php?id={$row['employeeNumber']}\">Details</a></td>";
        echo "<td><a href=\"update.php?id={$row['employeeNumber']}\">Update</a></td>";
        echo "<td><a href=\"delete.php?id={$row['employeeNumber']}\" "."onclick=\"return confirm('Are you sure you want to delete: ".strtoupper($row['firstName'])." ".strtoupper($row['lastName'])."')\">delete</a></td>";
        
        echo "</tr>";
    }
    echo "</table>";
    mysqli_close($conn);
    ?>
</body>
</html>
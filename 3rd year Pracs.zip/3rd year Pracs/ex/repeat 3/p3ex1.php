<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <legend><h1>Add new employee</h1></legend>
    <form action="p3ex1.php" method="POST">
        <label for="employee">Employee Number:</label><br>
        <input type="text" name="employeeNumber" required maxlength="4"><br>
        <label for="lastname">Last Name:</label><br>
        <input type="text" name="lastName" required><br>
        <label for="firstname">First Name:</label><br>
        <input type="text" name="firstName" required><br>
        <label for="ext">Extension:</label><br>
        <input type="text" name="extension" pattern="[a-z]{1}[0-9]{3,4}" required maxlength="5"><br>
        <label for="email">Email:</label><br>
        <input type="email" name="email" required><br>
        <label for="off">Office Code:</label><br>
        <input type="text" name="officeCode" maxlength="1" required><br>
        <label for="reports">Reports To:</label><br>
        <input type="text" name="reportsTo" maxlength="4" required><br>
        <select name="jobTitle" id="jobTitle"><br><br>
            <option value="1">President</option>
            <option value="2">Sales Manager (APAC)</option>
            <option value="2">Sale Manager (EMEA)</option>
            <option value="4">Sales Manager (NA)</option>
            <option value="4">VP Sales</option>
            <option value="5">Sales Rep</option>
        </select><br><br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    //self ref form
    if(isset($_REQUEST['submit'])){
        //stroee values from form
        $employeeNumber = $_REQUEST['employeeNumber'];
        $lastName = $_REQUEST['lastName'];
        $firstName = $_REQUEST['firstName'];
        $extension = $_REQUEST['extension'];
        $email = $_REQUEST['email'];
        $officeCode = $_REQUEST['officeCode'];
        $reportsTo = $_REQUEST['reportsTo'];
        $jobTitle = $_REQUEST['jobTitle'];
        //credentials
        require_once("config.php");
        //connect to databse
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                    or die("Error: could not connect to Database!!");
        //issue instruction via query
        $query = "INSERT INTO employees(employeeNumber, lastName, firstName, extension, email, officeCode, reportsTo, jobTitle)
                    VALUE('$employeeNumber', '$lastName', '$firstName', '$extension', '$email', '$officeCode', '$reportsTo', '$jobTitle');";
        $result = mysqli_query($conn,$query)
                or die("Error: could not issue instructions!!");
        //close connection and display message
        mysqli_close($conn);
        //
        echo "<h2 style=\"color:green\">The new employee was added!!</h2>";
    }
    ?>
</body>
</html>
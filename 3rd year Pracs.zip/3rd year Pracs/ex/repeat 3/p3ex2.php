<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new product line</h1>
    <form action="p3ex2.php" method="POST" enctype="multipart/form-data">
        <label for="prod">Product line:</label><br>
        <input type="text" required name="productLine"><br>
        <label for="desc">Description:</label><br>
        <textarea name="textDescription" id="textDescription" cols="30" rows="10"></textarea><br>
        <label for="picture">Picture:</label><br>
        <input type="file" name="picture" required><br><br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //call vales from form
    $productLine = $_REQUEST['productLine'];
    $textDescription = $_REQUEST['textDescription'];
    $htmlDescription = "<p>$textDescription</p>";
    //picture
    $picture = time().$_FILES['picture']['name'];
    //give the file a destination
    $destination = "images/".$picture;
    move_uploaded_file($_FILES['picture']['tmp_name'],$destination);
    //credentials via config
    require_once("config.php");
    //connect to DB
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: could not connect to Database");
    //issue instruction via query
    $query = "INSERT INTO productlines (productLine, textDescription, htmlDescription, image)
    VALUES ('$productLine', '$textDescription', '$htmlDescription', '$picture');";
    $result = mysqli_query($conn,$query)
            or die("Error: could not issue instruction!!!");
    //cloe connection and display message
    mysqli_close($conn);
    echo "<h1 style=\"color:green\">Product line added!!!!!!!!</h1>";
    }    
    ?>
</body>
</html>
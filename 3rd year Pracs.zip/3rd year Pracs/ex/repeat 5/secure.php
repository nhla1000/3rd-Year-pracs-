<?php
//start session
session_start();
//
if(!isset($_SESSION['access'])){
    header("location:login.html");
}
?>
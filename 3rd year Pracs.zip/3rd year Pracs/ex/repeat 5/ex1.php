<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Search Customer Credit Limit</h1>
    <form action="ex1.php" method="POST">
        <input type="search" name="search">
        <input type="submit" name="submit" value="Go">
    </form><br>
    <?php
    if(isset($_REQUEST['submit'])){
            //store value from the form
            $search = $_REQUEST['search'];
            //credentials via config
            require_once("config.php");
            //connect to database
            $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                    or die("Error: could no connect to Database!!");
            //issue instruction via query
            $query = "SELECT customerNumber, customerName FROM customers
            WHERE customerName LIKE '%$search%'
            ORDER BY customerName ASC";
            $result = mysqli_query($conn,$query)
                    or die("Error: could not execute query!!!");
            //display in number format
            echo "<ol>";
            //use while to display customer names
            while($row = mysqli_fetch_array($result)){
                echo "<li>";
                echo "<a href=\"credit.php?id={$row['customerNumber']}\">{$row['customerName']}</a>";
                echo "</li>";
            }
            echo "</ol>";
            //close connection
            mysqli_close($conn);
    }
    ?>
</body>
</html>
<?php
require_once("secure.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //start sesiion
    session_start();
    //store values from form
    $username = $_REQUEST['user'];
    $pass = $_REQUEST['password'];
    //if values are correct
    if($username == "Nhlanhla" && $pass == "12345"){
        //this user exis
        $_SESSION['access'] = "yes";
        $_SESSION['user'] = $username;
        //redirect user
        header("Location:ex2.php");
    } 
    else {
        header("Location:login.html");
    }
    ?>
</body>
</html>
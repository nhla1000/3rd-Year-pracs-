<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Search Customers Credit Limit</h1>
    <form action="ex1.php" method="POST">
        <input type="search" name="search">
        <input type="submit" name="submit" value="Go">
    </form>
    <?php
    //self ref form
    if(isset($_REQUEST['submit'])){
        //store value from form
        $search = $_REQUEST['search'];
        //credentials
        require_once("config.php");
        //connect to databse
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to DB!!");
        // issue instruction via query
        $query = "SELECT customerNumber, customerName FROM customers
        WHERE customerName LIKE '%$search%'
        ORDER BY customerName ASC";
        $result = mysqli_query($conn,$query) 
                or die("Error: could not execute query!!");
        //start displaying the number system
        echo "<ol>";
        //while to fetch coloums from database
        while($row = mysqli_fetch_array($result)){
            echo "<li>";
            echo "<a href=\"credit.php?id={$row['customerNumber']}\">{$row['customerName']}</a>";
            echo "</li>";
        }
        echo "</ol>";
        //close connection
        mysqli_close($conn);
    }
    ?>
</body>
</html>
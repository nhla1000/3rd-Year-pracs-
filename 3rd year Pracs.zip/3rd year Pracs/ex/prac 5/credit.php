<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id from prev page
    $cust_ID = $_REQUEST['id'];
    //credentials via config
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die("Error: Could not connect to database!!");
    //issue instruction via query
    $query = "SELECT customerName, creditLimit FROM customers WHERE customerNumber =
    $cust_ID";
    $result = mysqli_query($conn,$query)
            or die("Error: could not issue instruction!!");
    //use while to echo results
    while($row = mysqli_fetch_array($result)){
        $name = $row['customerName'];
        $credit = $row['creditLimit'];
    }
    //display result
    echo "<h2>" .strtoupper($name)."</h2>";
    echo "<p> Credit Limit = R". number_format($credit,0) ."</p>";
    //close connectons
    mysqli_close($conn);
    ?>
</body>
</html>
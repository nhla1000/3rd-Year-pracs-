<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        <?php
        //credentials via config
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to Database!!");
        //issue instruction via query
        $query = "SELECT customerName, sum(amount)
            FROM payments
            INNER JOIN customers
            ON payments.customerNumber = customers.customerNumber
            GROUP BY payments.customerNumber, customers.customerNumber
            ORDER BY sum(amount) DESC
            LIMIT 5";
        $result = mysqli_query($conn,$query)
                    or die("Error: could not execute query");
        //display array & task name
        echo "var data = google.visualization.arrayToDataTable([";
        echo "['Task', 'Amount'],";
        //use while to fetch info from database
        while($row = mysqli_fetch_array($result)){
            echo "['{$row['customerName']}', {$row['sum(amount)']}],";
        }
        echo "]);";
        //close connection
        mysqli_close($conn);
        ?>
        var options = {
          title: 'Amount spent by top 5 customers',
          hAxis: {
            title: 'Customers'
          },
          vAxis: {
            title: 'Rands'
          }
        };

        var chart = new google.visualization.ColumnChart(document.getElementById('columnchart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="columnchart" style="width: 900px; height: 500px;"></div>
  </body>
</body>
</html>
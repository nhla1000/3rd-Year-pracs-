<?php
require_once("secure.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //start session
    session_start();
    //store values from form
    $username = $_REQUEST['user'];
    $password = $_REQUEST['pass'];
    //if correct then 
    if($username == "Thabo" && $password = "123abc"){
        //then this user exists
        $_SESSION['access'] = "yes";
        $_SESSION['user'] = $username;
        //therfore redirect user
        header("Location:ex2.php");
    }
    //else this user doesnt exist
    else{
        header("Location:login.html");
    }
    ?>
</body>
</html>
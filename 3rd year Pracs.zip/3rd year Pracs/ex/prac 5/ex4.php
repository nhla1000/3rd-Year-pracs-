<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Customer Credit Limit</h1>
    <form action="ex4.php" method="POST" enctype="multipart/form-data">
        <input type="submit" name="submit" value="Export as textfile">
    </form>
    <?php
    //self ref form
    if(isset($_REQUEST['submit'])){
        //credentials via php
        require_once("config.php");
        //connect to databse
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
                or die("Error: could not connect to DB!!");
        //issue instruction via query
        $query = "SELECT customerName, creditLimit FROM customers ORDER BY customerName ASC";
        $result = mysqli_query($conn,$query)
                or die("Error: could not issue instruction!!");
        //give the file a name
        $filename = "credit.txt";
        //open the file
        $file = fopen($filename,"a") or die ("Error: could not open file!!");
        //use while to write in textfule
        while($row = mysqli_fetch_array($result)){
            $name = $row['customerName'];
            $credit = $row['creditLimit'];
            //write
            $text = $name." = R".$credit."\n";
            //write
            fwrite($file,$text);
        }
        //close file
        fclose($file);
        //close connection
        mysqli_close($conn);
        //display message
        echo "<h2 style=\"background-color:green\">Exported successfully</h2>";
    }
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //create variables for pounds
    $pounds = 181;
    //convert
    $stone = intval($pounds/14);
    $remained = $pounds%14;
    $kilo = number_format($pounds*0.453592,1);
    //echo
    echo "<table>
    <tr>
        <th><strong>Pounds</strong></th>
        <th><strong>Stone/Pounds</strong></th>
        <th><strong>Kilograms</strong></th>
    </tr>
    <tr>
        <td>$pounds lb</td>
        <td>$stone st - $remained st</td>
        <td>$kilo kg</td>
    </tr>
</table>"
    ?>
</body>
</html>
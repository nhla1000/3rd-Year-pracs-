<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //create the string
    $string = "apple banana cherry";
    //string replace
    $replace = str_replace("a", "x", $string);
    //display result
    echo "<strong>$string</strong><br><br><strong>$replace</strong>";
    ?>
</body>
</html>
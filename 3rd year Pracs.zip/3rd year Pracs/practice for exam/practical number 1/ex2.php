<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //define constants
    define("num1", 100);
    define("num2",50);
    //calculations
    $sum = num1 + num2;
    $diff = num1 - num2;
    $prod = num1*num2;
    //
    echo "Sum = $sum <br> Difference = $diff <br> Product = $prod";
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Laptop Categories</h1>
    <form action="ex2.php" method="POST">
        <label for="price">Laptop Price (Rands): </label>
        <input type="text" name="price" minlength="1" placeholder="enter value" required><br>
        <input type="submit" name="submit" value="Display category">
    </form>
    <?php
    //
    if(isset($_REQUEST['submit'])){
        //call values from form
        $Price = $_REQUEST['price'];
        //conditions and echo in each condition
        if($Price > 0 && $Price <= 9999){
            echo "<h3>Your laptop falls into the <strong>Home</strong> category</h3>";
        }
        elseif($Price >= 10000 && $Price <= 19999){
            echo "<h3>Your laptop falls into the <strong>Mainstream</strong> category</h3>";
        } 
        elseif($Price >= 20000 && $Price <= 29999){
            echo "<h3>Your laptop falls into the <strong>High Performance</strong> category</h3>";
        }
        else {
            echo "<h3>Your laptop falls into the <strong>Gaming</strong> category</h3>";
        }
    }
    ?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Names</h1>
    <form action="ex3.php" method="POST">
        <input type="text" name="name1"><br>
        <input type="text" name="name2"><br>
        <input type="text" name="name3"><br>
        <input type="text" name="name4"><br>
        <input type="text" name="name5"><br>
        <input type="text" name="name6"><br>
        <input type="text" name="name7"><br>
        <input type="text" name="name8"><br>
        <input type="text" name="name9"><br>
        <input type="text" name="name10"><br>
        <input type="submit" name="submit" value="Display in table">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //display table
    echo "<table>
    <tr>
    <th>Names</th>
    </tr>";
    //foreach loop
    foreach($_REQUEST as $value){
        //echo
    echo "<tr>";
    echo "<td>$value</td>";
    echo "<tr>";
    }
    echo "</table>";
    }
    ?>
</body>
</html>
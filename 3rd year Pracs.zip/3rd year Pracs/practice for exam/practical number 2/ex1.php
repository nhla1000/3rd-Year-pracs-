<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Due date calculator</h1>
    <form action="ex1.php" method="POST">
        <label for="purchase">Purchase Date:</label><br>
        <input type="date" name="date"><br>
        <input type="submit" name="submit" value="Calculate Due Date">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //cal value from form
        $Date = $_REQUEST['date'];
        //covert string to time
        $stringtotime = strtotime($Date);
        //add 30 days to the date
        $add = strtotime("+30 days", $stringtotime);
        //change date format
        $date = date("d-M-Y", $add);
        //display result
        echo "<h1>Payment due date</h1><br><h3>This bill will be due on $date</h3>";
    }
    ?>
</body>
</html>
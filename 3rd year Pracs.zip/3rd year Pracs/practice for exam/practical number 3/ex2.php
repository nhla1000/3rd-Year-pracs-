<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Add new product line</h1>
    <form action="ex2.php" method="POST" enctype="multipart/form-data">
        <label for="productline">Product line:</label><br>
        <input type="text" name="prodline" required><br>
        <label for="description">Description:</label><br>
        <textarea name="desc" id="desc" cols="30" rows="10"></textarea><br>
        <label for="picture">Picture:</label><br>
        <input type="file" name="picture" required><br>
        <input type="submit" name="submit" value="Add">
    </form>
    <?php
    if(isset($_REQUEST['submit'])){
        //call info from form
        $product = $_REQUEST['prodline'];
        $desc = $_REQUEST['desc'];
        $htmldesc = "<p>". $desc ."</p>";
        //picture
        $pic = time().$_FILES['picture']['name'];
        //destination
        $destination = "images/".$pic;
        move_uploaded_file($_FILES['picture']['tmp_name'],$destination);
        //login credentials via config
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
                or die ("Error: could not connect to the databse");
        //issue instruction via query
        $query = "INSERT INTO productlines (productLine, textDescription, htmlDescription, image)
        VALUE('$product', '$desc', '$htmldesc', '$pic')";
        $result = mysqli_query($conn,$query) 
            or die("Error: could not issue instruction!!");
        //close connection
        mysqli_close($conn);
        //display message if successful
        echo "<h2 style=\"color: green\">The new product was added successfully</h2>";
    }
    ?>
</body>
</html>
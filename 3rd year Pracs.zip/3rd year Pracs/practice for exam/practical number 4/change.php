<?php
        //call values from form
        $id = $_REQUEST['id'];
        $jobTitle = $_REQUEST['jobTitle'];
        $extension = $_REQUEST['extension'];
        $email = $_REQUEST['email'];
        $officeCode = $_REQUEST['officeCode'];
        $reportsTo = $_REQUEST['reportsTo'];
        //credentials via php
        require_once("config.php");
        //connect to database
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
                or die ("error but hey man");
                //issue inscr
        $query = "UPDATE employees SET jobTitle = '$jobTitle', extension = '$extension',
        email = '$email', officeCode = '$officeCode',
        reportsTo = '$reportsTo'
        WHERE employeeNumber = $id";
        $result = mysqli_query($conn,$query) 
                or die ("Error");
        //close connection
        mysqli_close($conn);
        //display message
        echo "<h1 style=\"color: green\">Successfully</h1>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
    //call id
    $id = $_REQUEST['id'];
    //login credntials
    require_once("config.php");
    //connect to database
    $conn  = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
        or die ("Error: could not connnect to databse");
    //issue instruction via query
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query) 
            or die ("Error: could not issue query");
    //use while to call in
    while($row = mysqli_fetch_array($result)){
        $jobTitle = $row['jobTitle'];
        $extension = $row['extension'];
        $email = $row['email'];
        $officeCode = $row['officeCode'];
        $reportsTo = $row['reportsTo'];
    }
    //close connection
    mysqli_close($conn);
    ?>
    <h1></h1>
    <form action="change.php" method="POST">
        <label for="job">Job Title:</label><br>
        <input type="text" name="jobTitle" value="<?php echo $jobTitle; ?>" required><br>
        <label for="extentsion">Extension:</label><br>
        <input type="text" name="extension" pattern="[x]{1}[0-9]{3,4}" maxlength="5" value="<?php echo $extension; ?>" required><br>
        <label for="email">eMail:</label><br>
        <input type="email" name="email" value="<?php echo $email; ?>" required><br>
        <label for="officecode">Office code:</label><br>
        <input type="text" name="officeCode" maxlength="1" value="<?php echo $officeCode; ?>" required><br>
        <label for="reportsto">Reports To:</label><br>
        <input type="text" name="reportsTo" value="<?php echo $reportsTo; ?>" required><br>
        <input type="hidden" name="id" value="<?php echo $id ?>">
        <input type="submit" name="submit" value="Update Record">
    </form>
</body>
</html>
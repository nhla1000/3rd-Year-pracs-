<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id passed through ex1
    $id = $_REQUEST['id'];
    //credentials via config
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE)
            or die ("Error: could not connect to database!!");
    //issue instruction via query
    $query = "SELECT * FROM employees WHERE employeeNumber = $id";
    $result = mysqli_query($conn,$query) 
            or die("Error: could not issue instruction");
    //while
    while($row = mysqli_fetch_array($result)){
        //display user name
    echo "<h1>{$row['firstName']} {$row['lastName']}</h1><br>";
    echo "<strong>Job Title: <nobr></strong>{$row['jobTitle']}<br>";
    echo "<strong>Extension: <nobr></strong>{$row['extension']}<br<";
    echo "<strong>eMail: <nobr></strong>{$row['email']}";
    }
    ?>
    &nl
</body>
</html>
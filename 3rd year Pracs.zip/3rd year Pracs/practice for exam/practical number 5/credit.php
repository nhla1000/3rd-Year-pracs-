<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //call id
    $cust_ID = $_REQUEST['id'];
    //credentials via config
    require_once("config.php");
    //connect to database
    $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABSE)
            or die("Error: could not connect to databse for credit!!");
    //issue instruction via query
    $query = "SELECT customerName, creditLimit FROM customers WHERE customerNumber =
    $cust_ID";
    $result = mysqli_query($conn,$query)
            or die("Error: could not execute query for credit!!");
    //use while to fetch info from databse and display
    while($row = mysqli_fetch_array($result)){
        echo "<h1>{$row['customerName']}</h1>";
        echo "<p>Credit limit: R".number_format($row['creditLimit'],0)."</p>";
    }
    //close connection
    mysqli_close($conn);
    ?>
</body>
</html>
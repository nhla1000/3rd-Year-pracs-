<?php
session_start();
if(isset($_SESSION['access'])){
    //remove all session variables
    session_unset();
    //destroy session
    session_destroy();
}
//redirect user
header("Location:login.html")
?>
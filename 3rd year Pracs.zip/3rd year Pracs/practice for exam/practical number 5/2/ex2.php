<?php
require_once("secure.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Search Customers Credit Limit</h1>
<p>Welcome <?php echo $_SESSION['user'] ?><a href="logout.php">(logout)</a></p>
    <form action="ex2.php" method="POST">
        <input type="search" name="search">
        <input type="submit" name="submit" value="Go"><br>
    </form>
    <?php
    //self ref form
    if(isset($_REQUEST['submit'])){
        $search = $_REQUEST['search'];
        //credentials via config
        require_once("config.php");
        //connect to databse
        $conn = mysqli_connect(SERVERNAME, USERNAME, PASSWORD, DATABASE) 
                or die("Error: could not connect to database!!");
        //isssue instruction via query
        $query = "SELECT customerNumber, customerName FROM customers
        WHERE customerName LIKE '%$search%'
        ORDER BY customerName ASC
        ";
        $result = mysqli_query($conn,$query) 
                or die("Error: could not issue instruction");
        //echo
        echo "<ol>";
        //while to fetch names from database and create variable
        while($row = mysqli_fetch_array($result)){
            //display names in number order
            echo "<li>";
            echo "<a href=\"credit.php?id={$row['customerNumber']}\">{$row['customerName']}</a>";
            echo "</li>";
        }
        //close ol
        echo "</ol>";
        //close connection
        mysqli_close($conn);
        
    }
    ?>
</body>
</html>